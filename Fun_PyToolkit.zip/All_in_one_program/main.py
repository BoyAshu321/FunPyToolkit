import sys
import os

project_dir = "/storage/emulated/0/All_in_one_program"
if project_dir not in sys.path:
    sys.path.append(project_dir)

from Programs.Games import menu as games_menu
from Programs.Maths import menu as maths_menu
from Programs.Others import menu as others_menu
from Programs.Fun import menu as fun_menu

def main_menu():
    while True:
        print("\n🔷 MAIN MENU")
        print("1. Games")
        print("2. Maths")
        print("3. Fun")
        print("4. Others")
        print("0. Exit")

        try:
            choice = int(input("Enter your choice: "))
            if choice == 1:
                games_menu.menu()
            elif choice == 2:
                maths_menu.menu() 
            elif choice == 3:
                fun_menu.menu()
            elif choice == 4:
                others_menu.menu() 
            elif choice == 0:
                print("Exiting All-in-One Program!")
                break
            else:
                print("Invalid input.")
        except ValueError:
            print("Please enter a valid number.")

main_menu()