from Programs.Maths import LCM_HCF_Finder, Prime_Number_Checker, Perimeter_Area_Finder, Statistics_Helper, Percentage_Helper

def menu():
    while True:
        print("\n🧮 Maths Menu")
        print("1. LCM-HCF Finder")
        print("2. Prime Number Checker")
        print("3. Perimeter-Area Finder")
        print("4. Statistics Helper")
        print("5. Percentage Helper")
        print("0. Back to Main Menu")

        try:
            choice = int(input("Choose an option: "))
            if choice == 1:
                LCM_HCF_Finder.menu()
            elif choice == 2:
                Prime_Number_Checker.menu()
            elif choice == 3:
                Perimeter_Area_Finder.menu()
            elif choice == 4:
                Statistics_Helper.menu()
            elif choice == 5:
                Percentage_Helper.menu()
            elif choice == 0:
                break
            else:
                print("Invalid choice.")
        except ValueError:
            print("Please enter a number.")