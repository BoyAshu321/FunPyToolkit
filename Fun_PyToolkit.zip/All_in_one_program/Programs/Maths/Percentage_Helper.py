def menu():
    while True:
        print("\nPercentage Helper")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                percentage_helper()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
 
def find_percentage_of_value():
     while True:
         try:
             first = int(input("\nEnter first value: "))
             second = int(input("\nEnter second value: "))
             break
         except:
             print("Plz enter numbers only")
             continue
             
     percentage =  (first/second)*100     
     print(f"\nPercentage: {percentage}%")

def find_value_of_percentage():
     while True:
         try:
             percent = int(input("\nEnter percent value: "))
             num = int(input("\nEnter value whose percent value you want to find: "))
             break
         except:
             print("Plz enter numbers only")
             continue
             
     value =  (percent/100)*num     
     print(f"\nvalue: {value}")         
                                  
def percentage_helper():
    print("\nAvailable options\n")
    print("1. Find percentage like what percentage 20 is of 40 etc ")
    print("2. Find the value of the percentage like 50% of 40")
    
    while True:
        try:
            choice = int(input("\nEnter your choice: "))
            if choice == 1:
                find_percentage_of_value()
                break
            elif choice == 2:
                find_value_of_percentage()
                break
            else:
                print("Wrong input plz enter 1 or 2 only")
                continue
        except:
            print("Plz enter numbers only")
            continue