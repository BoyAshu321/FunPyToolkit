def menu():
    while True:
        print("\nLCM-HCF Finder")
        print("1. Use LCM finder")
        print("2. Use HCF finder")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                lcm() 
            elif user == 2:
                hcf() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def lcm():
    a, b = get_input()
    LCM = (a*b) // auto_hcf(a, b)
    print(f"Your LCM is {LCM}")
    return

def auto_hcf(a, b):        
   while b != 0:
        a, b = b, a % b
   return a    
            
def hcf():
   a, b = get_input()                 
   while b != 0:
        a, b = b, a % b
   print(f"Your HCF is {a}")
        
def get_input():
    while True:
        try:
            first_num = int(input("\nEnter first number: "))
            second_num = int(input("\nEnter second number: "))
            return first_num, second_num        
        except:
           print("Plz enter a numbers only")