import math

def menu():
    while True:
        print("\nPerimeter/Area Finder")
        print("1. Find Perimeter")
        print("2. Find Area")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                find_perimeter() 
            elif user == 2:
                find_area() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def square(choice):
    while True:
        try:
            side = int(input("\nEnter side length: "))
            break
        except:
            print("Please enter numbers only.")
    
    if choice == "Perimeter":
        print("\nPerimeter:", 4 * side)
    else:
        print("\nArea:", side * side)

def rectangle(choice):
    while True:
        try:
            length = int(input("\nEnter length: "))
            breadth = int(input("Enter breadth: "))
            break
        except:
            print("Please enter numbers only.")
    
    if choice == "Perimeter":
        print("\nPerimeter:", 2 * (length + breadth))
    else:
        print("\nArea:", length * breadth)

def triangle(choice):
    if choice == "Perimeter":
        while True:
            try:
                a = int(input("\nEnter side a: "))
                b = int(input("Enter side b: "))
                c = int(input("Enter side c: "))
                break
            except:
                print("Please enter numbers only.")
        print("\nPerimeter:", a + b + c)
    else:
        while True:
            try:
                base = int(input("\nEnter base: "))
                height = int(input("Enter height: "))
                break
            except:
                print("Please enter numbers only.")
        print("\nArea:", 0.5 * base * height)

def circle(choice):
    while True:
        try:
            radius = int(input("\nEnter radius: "))
            break
        except:
            print("Please enter numbers only.")
    
    if choice == "Perimeter":
        print("\nCircumference:", 2 * math.pi * radius)
    else:
        print("\nArea:", math.pi * radius * radius)

def find_perimeter():
    shapes = ["Square", "Rectangle", "Triangle", "Circle"]
    print("\nAvailable shapes:", ", ".join(shapes))
    
    while True:
        shape = input("\nEnter shape: ").lower().capitalize().strip()
        if shape not in shapes:
            print("Your shape is not in available shapes or you entered something wrong. Please try again.")
            continue
        else:
            if shape == "Square":
                square("Perimeter")
            elif shape == "Rectangle":
                rectangle("Perimeter")
            elif shape == "Triangle":
                triangle("Perimeter")
            elif shape == "Circle":
                circle("Perimeter")
            break

def find_area():
    shapes = ["Square", "Rectangle", "Triangle", "Circle"]
    print("\nAvailable shapes:", ", ".join(shapes))
    
    while True:
        shape = input("\nEnter shape: ").lower().capitalize().strip()
        if shape not in shapes:
            print("Your shape is not in available shapes or you entered something wrong. Please try again.")
            continue
        else:
            if shape == "Square":
                square("Area")
            elif shape == "Rectangle":
                rectangle("Area")
            elif shape == "Triangle":
                triangle("Area")
            elif shape == "Circle":
                circle("Area")
            break