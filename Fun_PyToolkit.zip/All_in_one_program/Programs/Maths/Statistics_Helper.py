def menu():
    while True:
        print("\nStatistics Helper menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                statistics_helper()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def find_mean(data):
    sum = 0
    for num in data:
        sum += num
        
    return sum/len(data)

def find_median(data):
    data.sort()  # Always sort first
    n = len(data)

    if n % 2 == 1:
        # Odd number of elements
        median = data[n // 2]
    else:
        # Even number of elements
        mid1 = data[n // 2 - 1]
        mid2 = data[n // 2]
        median = (mid1 + mid2) / 2

    return median
    
def find_mode(data):
    freq = {}  # Dictionary to store frequencies

    for value in data:
        if value in freq:
            freq[value] += 1
        else:
            freq[value] = 1

    max_count = max(freq.values())  # Highest frequency

    # Get all values with highest frequency
    mode = [key for key, count in freq.items() if count == max_count]

    return mode
        
def statistics_helper():
    sum = 0
    
    while True:
        try:
            user_list = list(map(int, input("\nEnter the numbers: ").split())) 
            break               
        except:
            print("Wrong inputs")
            continue
                                   
    mean = find_mean(user_list)
    median = find_median(user_list)
    mode = find_mode(user_list)
    range = max(user_list)-min(user_list)
    
    print(f"\nMean: {mean}")
    print(f"Median: {median}")
    print(f"Mode: {mode}")
    print(f"Range: {range}") 