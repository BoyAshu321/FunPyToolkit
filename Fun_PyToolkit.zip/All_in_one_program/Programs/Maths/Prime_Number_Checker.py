def menu():
    while True:
        print("\nPrime number checker menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                check_prime()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def check_prime():    
    while True:
        try:
            num = int(input("\nEnter the number: "))
            if num < 2:
                print(f"{num} is not a prime number")
                return
            break
        except ValueError:
            print("Please enter positive numbers only")

    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            print(f"\n{num} is not a prime number")
            factors = [i for i in range(1, num+1) if num % i == 0]
            print(f"\nFactors: {factors}")
            return

    print(f"\n{num} is a prime number")