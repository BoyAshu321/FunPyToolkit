def menu():
    while True:
        print("\nEncryption/decryption menu")
        print("1. Use encryption")
        print("2. Use decryption")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                encryption()
            elif user == 2:
                decryption()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.") 

                        
def encryption():
    letters = "abcdefghijklmnopqrstuvwxyz"
    
    while True:
        try:
            key = int(input("\nEnter the key (1-25): "))
            if 1 <= key <= 25:
                break
            else:
                print("Plz only enter key in range 1-25")
                continue
        except:
            print("Plz enter number only")
            continue
            
    shifted_letters = letters[key:] + letters[:key]
    
    sentence = input("\nEnter your sentence: ").lower()   
    
    encrypted_sentence = ""
    
    for char in sentence:
        if char in letters:
          encrypted_sentence += shifted_letters[letters.index(char)]
        else:
            encrypted_sentence += char
                
    print("\nYour encrypted sentence is given below\n")   
    print(encrypted_sentence.capitalize())   
    
     
def decryption():
    letters = "abcdefghijklmnopqrstuvwxyz"
    
    while True:
        try:
            key = int(input("\nEnter the key (1-25): "))
            if 1 <= key <= 25:
                break
            else:
                print("Plz only enter key in range 1-25")
                continue
        except:
            print("Plz enter number only")
            continue
            
    shifted_letters = letters[key:] + letters[:key]
    
    sentence = input("\nEnter your sentence: ").lower()   
    
    decrypted_sentence = ""
    
    for char in sentence:
        if char in letters:
          decrypted_sentence += letters[shifted_letters.index(char)]
        else:
            decrypted_sentence += char
                
    print("\nYour decrypted sentence is given below\n")   
    print(decrypted_sentence.capitalize())
    