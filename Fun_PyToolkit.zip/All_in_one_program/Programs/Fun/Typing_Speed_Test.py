import time
import string

def menu():
    while True:
        print("\nTyping Speed Test menu")
        print("1. Try")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                typing_speed_test()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def clean(word):
    return word.strip(string.punctuation).lower()
 
def test(difficulty):
    stories = [
    # Story 1 – Very Easy (Beginner words)
    "The sun was shining. A boy went to the park. He saw a dog playing with a ball. The grass was green and soft. He sat under a tree. Birds were singing. A girl came with her kite. They smiled and played together. The dog barked happily. Clouds moved slowly in the sky. The boy ate a sandwich. The girl had juice. They shared food with the dog. A man walked by and waved. It was a fun day. They laughed, played, and had fun. As the sun set, they said goodbye. They went home smiling. It was a good day.",

    # Story 2 – Easy (Common story words)
    "Anna loved to read books. Every morning, she would sit by the window and read stories. Her favorite book was about a brave girl who traveled to different lands. One day, Anna dreamed of flying. She imagined herself with wings, soaring above clouds. Her room became a castle. Her bed turned into a ship. She sailed through stars. The moon waved at her. She saw dragons, unicorns, and talking trees. Suddenly, her alarm rang. It was time for school. She smiled. Her dreams were magical. She packed her bag and walked out. But deep inside, she was still flying free.",

    # Story 3 – Medium (More vivid and descriptive)
    "The forest was quiet as Leo walked down the narrow path. Leaves crunched under his boots. A soft breeze touched his face. Birds chirped above, hidden in the thick branches. He carried a backpack with snacks and a flashlight. Suddenly, he saw a deer drinking from a clear stream. He froze, watching its graceful movements. The deer looked up, then ran away. Leo smiled. He reached a small cabin made of old wood. He opened the door and went inside. There was a fireplace, a table, and an old book. He sat, read for hours, then fell asleep peacefully inside.",

    # Story 4 – Harder (Story with more complexity)
    "In a distant kingdom, there lived a young inventor named Elara. She loved building machines that helped people. Her latest project was a flying cart that ran on sun power. Many laughed at her ideas. But she kept working. One morning, the cart lifted off! People cheered. But during the flight, it began to fall. Elara quickly fixed the wing using a rope and a metal rod. The cart flew again, smoother than before. She landed it gently in the village. Everyone clapped. Her courage, skills, and calm thinking saved the day. From then on, she was called Sky Queen Elara.",

    # Story 5 – Complex (Hard vocabulary and sentence flow)
    "Beneath the shadow of towering mountains, an ancient village lay undisturbed by time. Elders spoke of a hidden relic buried under the temple ruins. Arin, a young scholar, arrived seeking truth. With maps, notes, and lantern in hand, he explored forgotten chambers and deciphered cryptic scripts etched in stone. Each step deeper unveiled secrets once lost. At last, he discovered a chamber glowing with strange light. The relic pulsed with energy. As he reached out, symbols floated midair. Knowledge flowed into his mind. Legends weren’t myths. He emerged transformed, burdened with wisdom, and the villagers called him the Guardian of Truth."
    ]
    
    if difficulty == "very easy":
        story = stories[0]
    elif difficulty == "easy":
        story = stories[1]
    elif difficulty == "medium":
        story = stories[2]
    elif difficulty == "hard":
        story = stories[3]
    else:
        story = stories[4]
    
    print(f"Story: {story}")
            
    input("\nPress enter to start the test....")
    
    for i in range(3, 0, -1):
        print(f"\nStarting in {i}")
        time.sleep(1)
        
    start = time.time()
    user_story = input("\nStart writing then press enter: ")
    time_taken = time.time()-start
    user_words = user_story.split()
    wpm = int(len(user_words) /(time_taken/60)) 
    story_words = story.split()
    correct = 0
    highlighted_words = {}
    for uw, sw in zip(user_words, story_words):
        if clean(uw) == clean(sw):
            correct += 1
        else:
            highlighted_words[clean(sw)] = clean(uw)
            
            
    accuracy = (correct/len(story_words))*100
    mistakes = len(highlighted_words)
                        
    print(f"\nAccuracy: {accuracy:.2f}")
    print(f"Correct words: {correct}/{len(story_words)}")
    print(f"WPM: {wpm}")
    
    for expected, actual in highlighted_words.items():
        print(f"Expected: {expected}/Got: {actual}")
        
    print(f"Time taken: {time_taken:.2f} seconds")
    print(f"Mistakes: {mistakes} out of {len(story_words)}")
    return
    
def typing_speed_test():
    
    while True:
        try:
            difficulty = int(input("\nEnter difficulty(1, 2, 3, 4, 5): "))
            if difficulty == 1:
                test("very easy")
            elif difficulty == 2:
                test("easy")
            elif difficulty == 3:
                test("medium")
            elif difficulty == 4:
                test("hard")
            elif difficulty == 5:
                test("complex")
            else:
                print("Invalid choice")
                continue                
        except:
            print("Plz enter numbers only")
            continue
            
        again = input("\nDo you want to try another test? (y/n): ").lower()
        if again == "y":
            continue