from Programs.Fun import Encryption_decryption, Word_Guessers, Memory_Challenge, Lucky_7, Typing_Speed_Test

def menu():
    while True:
        print("\n🎮 Fun Menu")
        print("1. Encryption/decryption")
        print("2. Word Guessers")
        print("3. Memory Challenge")
        print("4. Lucky 7")
        print("5. Typing Speed test")
        print("0. Back to Main Menu")

        try:
            choice = int(input("\nChoose an option: "))
            if choice == 1:
                Encryption_decryption.menu()
            elif choice == 2:
                Word_Guessers.menu()
            elif choice == 3:
                Memory_Challenge.menu()
            elif choice == 4:
                Lucky_7.menu()
            elif choice == 5:
                Typing_Speed_Test.menu()
            elif choice == 0:
                break
            else:
                print("Invalid choice.")
        except ValueError:
            print("Please enter a number.")