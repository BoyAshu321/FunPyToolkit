import random
import time

def menu():
    while True:
        print("\nWord Guessers menu")
        print("1. Brute Force Word Guesser")
        print("2. Brute Force Word Guesser with known letters") 
        print("3. Fastest Word Guesser")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                brute_force_word_guesser()
            elif user == 2:
                faster_brute_force_word_guesser() 
            elif user == 3:
                fastest_word_guesser() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number")
            
def brute_force_word_guesser():
    print("\nWelcomd to brute force word guesser as the name suggests this program will try to guess your word radomly\n")
    print("Instructions:\n")
    print("1. Enter lowercase letters only")
    print("2. Plz don't use spaces")
    print("3. Plz don't use any other symbol or digit expect lowercase letters")
    print("4. If you break any of those above rules then the program will try to guess your word endlessly and never stop because we haven't upgraded it to handle symbols, spaces and digits because if we do then it would become very time consuming for it to guess your word")
    
    letters = "abcdefghijklmnopqrstuvwxyz"
    word = input("\nEnter the word: ").lower()
    start = time.time() 
    guessed_word = ""
    time_taken = None
    attempts = 0
    
    while True:
        for i in range(len(word)):
            guessed_word += random.choice(letters)
        if guessed_word == word:
            attempts += 1
            print(f"\nWord finded your word was: {guessed_word}")
            time_taken = time.time()-start
            print(f"Time taken: {time_taken}")
            print(f"Attempts taken: {attempts}")
            break
        else:
            print(guessed_word)
            guessed_word = "" 
            attempts += 1
            
def faster_brute_force_word_guesser():
    print("\nWelcome to faster brute force word guesser as the name suggests this program will try to guess your word but this time it would know the letters of your word but remember this can also slow down or guess endlessly if you use more letters")
    
    word = input("\nEnter the word: ")
    start = time.time()
    word_list = list(word)
    guessed_word = ""
    time_taken = None
    attempts = 0
    
    while True:
        random.shuffle(word_list)
        guessed_word = "".join(word_list)
        if guessed_word == word:
            attempts += 1
            print(f"\nWord finded your word was: {guessed_word}")
            time_taken = time.time()-start
            print(f"Time taken: {time_taken}")
            print(f"Attempts taken: {attempts}")
            break
        else:
            print(guessed_word)
            guessed_word = ""
            attempts += 1
            
def fastest_word_guesser():
    print("\nWelcome to the fastest word guesser it will guess your word instantly if you don't believe then try it")
    
    word = input("\nEnter your word: ")
    print(f"\nWord finded your word was: {word}")
    print("Time taken: 0.000000001")
    print("Attempts taken: 1")