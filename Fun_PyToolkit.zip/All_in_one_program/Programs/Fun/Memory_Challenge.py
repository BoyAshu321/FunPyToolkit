import time
import random

def menu():
    while True:
        print("\nMemory Challenge Menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                memory_challenge() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def choose_letters(current_level, letters):
    selected = ""
    for _ in range(current_level):
        selected += random.choice(letters)
    return selected

def memory_challenge():
    print("\nWelcome to Memory Challenge!")
    print("You'll see a random sequence of letters. Try to memorize it.")
    print("Each level will get harder. Good luck!\n")
    input("Press Enter to start...")
    
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"    
    current_level = 1
    score = 0
    
    while True:
        selected_letters = choose_letters(current_level, letters)
       
        print(f"\nMemorize (Level {current_level}): {selected_letters}")
        time.sleep(current_level)
        for i in range(3, 0, -1):
            print(f"Hiding in {i}...")
            time.sleep(1)
        print("\n"*100)
        
        user = input("\nType the sequence (letters like A, B, C, D etc): ").upper().strip()

        if user != selected_letters:
            print("Wrong input!")
            print(f"Correct was: {selected_letters}") 
            print(f"\nGame Over at Level {current_level}")
            print(f"Final Score: {score}")
            again = input("\nPlay again? (y/n): ").lower()
            if again != 'y':
                break
            else:
                current_level = 1
                score = 0
        else:
            print("Correct! Going to next level...")
            current_level += 1
            score += 1
            time.sleep(1)
        if current_level > 20:
            print("🎉 You beat the final level! You're a memory master!")
            again = input("\nPlay again? (y/n): ").lower()
            if again != 'y':
               break
            else:
               current_level = 1
               score = 0