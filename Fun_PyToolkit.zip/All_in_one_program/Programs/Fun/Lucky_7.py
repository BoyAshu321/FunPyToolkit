import random

def menu():
    while True:
        print("\nLucky 7 menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                play()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
 
def play():
    num = random.randint(2, 12)
    score = 0
    
    while True:
        user = input("\nChoose Above, Below or Exactly: ").capitalize().strip()
        if user not in ["Above", "Below", "Exactly"]:
            print(f"Expected Above, Below or Exactly got {user} plz try again")
            continue
        else:
            if user == "Above" and num > 7:
                print("\nCorrect")
                print(f"The number was {num}")
                score += 1
                print(f"Current Score: {score}")
                print("\nMoving next")
                num = random.randint(2, 12)
                continue
            elif user == "Below" and num < 7:
                print("\nCorrect")
                print(f"The number was {num}")
                score += 1
                print(f"Current Score: {score}")
                print("\nMoving next")
                num = random.randint(2, 12)
                continue
            elif user == "Exactly" and num == 7:
                print("\nCorrect")
                print(f"The number was {num}")
                score += 2
                print(f"Current Score: {score}")
                print("\nMoving next")
                num = random.randint(2, 12)
                continue
            else:
                print("\nWrong guess you lost")
                print(f"The number was {num}")
                print(f"Score achieved: {score}")
                
                again = input("\nDo you want to play again (y/n): ")
                if again != "y":
                    print("\nThanks for playing")
                    break
                else:
                    num = random.randint(2, 12)
                    score = 0