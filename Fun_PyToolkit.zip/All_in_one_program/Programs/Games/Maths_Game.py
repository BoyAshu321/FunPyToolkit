import time
import random

def menu():
    while True:
        print("\nMaths Game menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                Maths_Game()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
  
def generate_question(level):
    operations = ['+', '-', '×', '÷']
    while True:
        op = input("\nChoose operation (+, -, ×, ÷): ")
        if op not in operations:
            print("Wrong operation")
            continue
        else:
            break
    
    if level == 1:
        a = random.randint(0, 9)
        b = random.randint(0, 9)
    elif level == 2:
        a = random.randint(0, 99)
        b = random.randint(0, 99)
    else:
        a = random.randint(0, 999)
        b = random.randint(0, 999)

    if op == '+':
        question = f"{a}+{b}"
        answer = a + b
    elif op == '-':
        question = f"{a}-{b}"
        answer = a - b
    elif op == '×':
        question = f"{a}×{b}"
        answer = a * b
    elif op == '÷':
        b = random.randint(1, 10)
        answer = random.randint(1, 10)
        a = b * answer
        question = f"{a}÷{b}"

    return question, answer                                

def game(question, answer, time_limit):
    start = time.time() 
    
    while True:
         try:
             user = int(input(f"\nWhat is {question}: "))
             if user == answer:
                 if time.time()-start > time_limit:
                   print("\nCorrect but slow")
                   break
                 else:
                     print("\nCorrect and fast")
                     break
             else:
                  print("\nWrong answer")
                  break
         except:
             print("Plz enter number only")
             continue    
                                                         
def Maths_Game():
    print("\nDifficulty levels\n")
    print("1. Easy")
    print("2. Medium")
    print("3. Hard")
    
    while True:        
        try:
            difficulty = int(input("\nEnter difficulty level (1,2,3): "))
            if 1 <= difficulty <= 3:
                break
            else:
                print("Difficulty should be between 1-3") 
                continue
        except:
             print("Plz enter difficulty in number from 1-3")
             continue
             
    question, answer = generate_question(difficulty)
    
    if difficulty == 1:
        time_limit = 3
    elif difficulty == 2:
        time_limit = 5
    else:
        time_limit = 10
        
    game(question, answer, time_limit)    