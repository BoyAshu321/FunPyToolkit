import random

def menu():
    while True:
        print("\nRock Paper Scissors Menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                play()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
        
def play():
    while True:
       possibilities = ["R","P", "S"]
       user = input("\nEnter R for rock, P for paper and S for scissors: ").capitalize() 
       comp = random.choice(possibilities)
       if user == "R" and comp == "S":
          print("You won")
          break
       elif user == "P" and comp == "R":
            print ("You won")
            break
       elif user == "S" and comp == "P":
            print("You won")
            break
       elif user == comp:
           print("It's a draw")
           break
       elif user not in possibilities:
            print("Sorry wrong input plz try again")
            continue
       else:
             print("You lost")  
             break
             