import random
import time

def menu():
    while True:
        print("\nWord Jumble menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                word_jumble()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def word_jumble():
    words = ["Apple", "Banana", "Orange", "Mango", "Watermelon", "India", "China", "Japan", "Mexico", "Russia", "Ironman", "Spiderman", "Batman", "Ali", "Thanos",]
    selected_word = random.choice(words).lower()   
    jumbled_word = "".join(random.sample(selected_word, len(selected_word)))
    tries = 0
    time_taken = None
    
    print(f"\nThe scrambled word is: {jumbled_word}")
    start = time.time()
    while True:
        user = input("\nGuess the scrambled word: ").lower()
        tries += 1
        if user == selected_word:
            time_taken = time.time()-start
            print(f"\nCongratulations! You guessed it: {selected_word.capitalize()}")
            print(f"Tries: {tries}")
            print(f"Time taken: {time_taken}")
            break
        else:
            print("\nWrong guess plz try again")
            continue