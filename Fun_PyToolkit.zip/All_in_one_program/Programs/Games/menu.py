from Programs.Games import Rock_Paper_Scissors, Guess_the_number, Sequence_Guesser, Maths_Game, Word_Jumble

def menu():
    while True:
        print("\n🎮 Games Menu")
        print("1. Rock Paper Scissors")
        print("2. Guess the number")
        print("3. Sequence Guesser")
        print("4. Maths Game")
        print("5. Word Jumble")
        print("0. Back to Main Menu")

        try:
            choice = int(input("Choose a game: "))
            if choice == 1:
                Rock_Paper_Scissors.menu()
            elif choice == 2:
                Guess_the_number.menu() 
            elif choice == 3:
                Sequence_Guesser.menu()
            elif choice == 4:
                Maths_Game.menu() 
            elif choice == 5:
                Word_Jumble.menu() 
            elif choice == 0:
                break
            else:
                print("Invalid choice.")
        except ValueError:
            print("Please enter a number.")