import random

def menu():
    while True:
        print("\nSequence Guesser menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                play() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def check_guess(guess, sequence):
    correct = 0
    for i in range(len(guess)):
        if guess[i] == sequence[i]:
            correct += 1
            
    return correct

def play():
    print("\n Welcome to sequence guesser")
    print("~~Rules~~")
    print("1. There will be a sequence of desired letters")
    print("2. The sequence will contain random English alphabet letters but Capital")
    print("3. Your goal is to guess the sequence")
    print("4. If any of your guessed letter matches the sequence and in the correct place then the program will say x correct where x is the number of correct letters")
    print("5. The sequence can also contain duplicates like if you choose length as 5 and get 4 letters then it means there is a duplicate")
    print("\nGood luck")
    
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    while True:
        try:
            length = int(input("\nEnter length of the sequence (4-16): "))
            if length < 4 or length > 16:
                print("Plz select from 4-16")
                continue
            else:
                break
        except:
            print("Plz enter number")
            continue
            
    letters_chosen = ""
    for i in range(length):
        letters_chosen += random.choice(letters)
        
    print(f"\nThe choosen letters are: {letters_chosen}")
    
    sequence_list = list(letters_chosen)
    random.shuffle(sequence_list)    
    sequence = "".join(sequence_list) 
  
    tries = 0
    while True:
        guess = input("\nYour guess: ").upper()
        if len(guess) > length or len(guess) < length:
            print(f"Your guess should be of {length} letters")
        elif set(guess).issubset(set(letters_chosen)) == False:
            print(f"Plz only use letters from {letters_chosen}")
            continue
        else:
            tries += 1
            correct = check_guess(guess, sequence) 
            if correct != length:
                print(f"\nYou got {correct} correct")
                print(f"Current tries: {tries}")
                continue
            else:
                   print(f"Congratulations!🎉 You got all correct in {tries}")
                   break            