import random

def menu():
    while True:
        print("\nGuess the number menu")
        print("1. Play")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                play()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def play():
    num = random.randint(1, 100)
    while True:
        try:
           user = int(input("\nGuess the number: "))
        except:
            print("Plz enter a number not something else")
            continue
        if user > 100 or user < 1:
            print("Plz guess between 1-100")
            continue
        elif user > num:
            print("Too high")
        elif user < num:
            print("Too low")
        else:
            print("Congratulations! You guessed it")
            break