import random

def menu():
    while True:
        print("\nPassword Generator menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                password() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def password_generator(difficulty, length):
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    numbers = "1234567890"
    symbols = "!@#$%^&*()-_=+[]{};:,.<>?/\\|"
    level = None
    password = ""
    if difficulty == 1:
        level = letters
    elif difficulty == 2:
        level = letters+numbers
    elif difficulty == 3:
        level = letters+numbers+symbols
    
    for i in range(length):
        password += random.choice(level)
    
    print("\nYour password is:")
    print(f"\n{password}")
    print("\nDon't tell this to anyone keep it safe🤫")
    

def password():    
    while True:
        print("\nDifficulties/levels")
        print("1. Easy(only letters)")
        print("2. Medium(letters+numbers)") 
        print("3. Hard(letters+numbers+symbols)")
        try:
            difficulty = int(input("\nSelect difficulty (1, 2,3): "))
            if difficulty < 1 or difficulty > 3:
                print("Plz select from 1-3")
                continue
            else:
                break
        except:
            print("Plz enter a number")
            continue
                     
    while True:       
        try:
            length = int(input("\nEnter length from 8 to 64: "))
            if length < 8 or length > 64:
                print("Plz select from 8-64")
                continue
            else:
                break
        except:
            print("Plz enter a number")
            continue
                
    password_generator(difficulty, length)