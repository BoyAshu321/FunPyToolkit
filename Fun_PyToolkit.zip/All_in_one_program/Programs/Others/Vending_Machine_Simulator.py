items = {"Pepsi": [10, 10], "Coke": [20, 5], "Chips": [20, 10], "Chocolate": [5, 10], "Kurkure": [10, 10], "Oreo": [10, 5]}

def menu():
    while True:
        print("\nVending Machine Simulator Menu\n")
        print("1. Add item")
        print("2. Remove item")
        print("3. Buy item")
        print("4. Change cost of an item")
        print("5. Change quantity of an item")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                add_item()
            elif user == 2:
                remove_item()
            elif user == 3:
                buy_item()
            elif user == 4:
                change_cost()
            elif user == 5:
                change_quantity()
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def show_items():
    if len(items) != 0:
        print("\nCurrent items:")
        for i, (item, cost_quantity) in enumerate(items.items()):
            print(f"{i+1}. Item: {item.ljust(12)} | Cost: ₹{cost_quantity[0]} | Quantity: {cost_quantity[1]}")
    else:
        print("\nCurrently there are no items")
                                    
def add_item():
    show_items()
    while True:
        try:
            item = input("\nEnter item name: ")
            cost = int(input(f"\nEnter {item}'s cost: "))
            quantity = int(input(f"\nEnter {item}'s quantity: "))
            print("\nThanks for adding something new")
            break
        except ValueError:
            print("It seems you entered something wrong. Please try again.")
            continue
            
    items[item] = [cost, quantity]
    show_items()

def remove_item():
    show_items()
    if len(items) != 0:
        while True:
            try:
                item = int(input("\nEnter the serial number of the item: "))
                if 1 <= item <= len(items):
                    key = list(items)[item-1]
                    del items[key]
                    if len(items) == 0:
                        print("\nIt was the last item. Now no more items left.")
                    else:
                        show_items()
                    break
                else:
                    print("Wrong serial number")
            except ValueError:
                print("Please enter a valid number")
                continue
    else:
        print("\nNo items to remove")

def buy_item():
    if len(items) != 0:
        show_items()
        while True:
            try:
                item = int(input("\nEnter serial number of item: "))
                if 1 <= item <= len(items):
                    key = list(items)[item-1]
                    quantity = int(input("\nEnter quantity: "))
                    if 1 <= quantity <= items[key][1]:
                        cost = items[key][0] * quantity
                        print(f"\nYou have to pay ₹{cost}")
                        while True:
                            try:
                                money = int(input("\nEnter money: "))
                                if money >= cost:
                                    change = money - cost
                                    if change > 0:
                                        print(f"\nHere is your change of ₹{change} and thanks for purchasing")
                                    else:
                                        print("\nThanks for purchasing")
                                    items[key][1] -= quantity
                                    if items[key][1] == 0:
                                        del items[key]
                                    break
                                else:
                                    print(f"\nYou can't give ₹{money} for ₹{cost}'s items. Please pay again.")
                            except ValueError:
                                print("Please enter a valid number")
                        break
                    else:
                        print("\nSorry, we don't have that much quantity. Please try again.")
                else:
                    print("\nWrong serial number. Please try again.")
            except ValueError:
                print("Please enter a valid number")
    else:
        print("\nNo items to buy")

def change_cost():
    show_items()
    while True:
        try:
            item = int(input("\nEnter the serial number of the item to change cost: "))
            if 1 <= item <= len(items):
                key = list(items)[item-1]
                while True:
                    try:
                        new_cost = int(input(f"\nEnter new cost for {key}: "))
                        if new_cost > 0:
                            items[key][0] = new_cost
                            print(f"\nCost updated successfully for {key}")
                            show_items()
                            break
                        else:
                            print("Cost cannot be 0 or negative")
                    except ValueError:
                        print("Cost should be a number")
                break
            else:
                print("Wrong serial number")
        except ValueError:
            print("Please enter a valid number")

def change_quantity():
    show_items()
    while True:
        try:
            item = int(input("\nEnter the serial number of the item to change quantity: "))
            if 1 <= item <= len(items):
                key = list(items)[item-1]
                while True:
                    try:
                        new_qty = int(input(f"\nEnter new quantity for {key}: "))
                        if new_qty >= 0:
                            items[key][1] = new_qty
                            print(f"\nQuantity updated successfully for {key}")
                            show_items()
                            break
                        else:
                            print("Quantity cannot be negative")
                    except ValueError:
                        print("Quantity should be a number")
                break
            else:
                print("Wrong serial number")
        except ValueError:
            print("Please enter a valid number")