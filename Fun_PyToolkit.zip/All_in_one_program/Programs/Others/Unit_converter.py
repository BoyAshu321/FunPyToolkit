def menu():
    while True:
        print("\nUnit Converter menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("Enter your choice: "))
            if user == 1:
                unit_converter() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
            
def converter(unit_from, unit_to, factor):
    while True:
        try:
            value = int(input(f"\nEnter the number ({unit_from}): "))
            converted = value * factor
            print(f"{value} {unit_from} is equal to {converted} {unit_to}")             
            break
        except:
             print("Plz enter number only")    
             continue          

def weight_converter():
     print("\nAvailable conversions:\n")
     print("1. kg to g") 
     print("2. g to kg")
     
     while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice < 1 or choice > 2:
                print("Plz enter your choice between 1-2")
                continue
            else:
                if choice == 1:
                    converter("kg", "g", 1000)
                    break
                elif choice == 2:
                    converter("g", "kg", 1/1000)
                    break
        except:
            print("Plz enter numbers only")
            continue  
     
def length_converter():
     print("\nAvailable conversions:\n")
     print("1. km to m") 
     print("2. m to km")
     
     while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice < 1 or choice > 2:
                print("Plz enter your choice between 1-2")
                continue
            else:
                if choice == 1:
                    converter("km", "m", 1000)
                    break
                elif choice == 2:
                    converter("m", "km", 1/1000)
                    break
        except:
            print("Plz enter numbers only")
            continue
            
def volume_converter():
     print("\nAvailable conversions:\n")
     print("1. l to ml") 
     print("2. ml to l")
     
     while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice < 1 or choice > 2:
                print("Plz enter your choice between 1-2")
                continue
            else:
                if choice == 1:
                    converter("l", "ml", 1000)
                    break
                elif choice == 2:
                    converter("ml", "l", 1/1000)
                    break
        except:
            print("Plz enter numbers only")
            continue

def time_converter():
     print("\nAvailable conversions:\n")
     print("1. min to sec") 
     print("2. sec to min")
     
     while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice < 1 or choice > 2:
                print("Plz enter your choice between 1-2")
                continue
            else:
                if choice == 1:
                    converter("min", "sec", 60)
                    break
                elif choice == 2:
                    converter("sec", "min", 1/60)
                    break
        except:
            print("Plz enter numbers only")
            continue
                                                                                  
def unit_converter():
    print("\nAvailable options:\n")
    print("1. Weight")
    print("2. Length")
    print("3. Volume")
    print("4.Time")
    
    while True:
        try:
            choice = int(input("Enter your choice: "))
            if choice < 1 or choice > 4:
                print("Plz enter your choice between 1-4")
                continue
            else:
                if choice == 1:
                    weight_converter() 
                    break
                elif choice == 2:
                    length_converter()
                    break
                elif choice == 3:
                    volume_converter() 
                    break
                elif choice == 4:
                    time_converter() 
                    break
        except:
            print("Plz enter numbers only")
            continue  
            