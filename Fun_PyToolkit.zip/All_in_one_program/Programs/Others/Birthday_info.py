import  calendar
from datetime import date

def menu():
    while True:
        print("\nBirthday info menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                Birthday_info() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")

def Birthday_info():
    print("\nInstructions\n")
    print("1. Only enter numbers")
    print("2. In your birth date plz enter number only")
    print("3. Your birth year should be between 1000-2025")
    print("3. Your month should be in number as well like 1 for January, 2 for February etc")
    
    while True:
            try:
                birth_year = int(input("\nEnter your birth year: ")) 
                birth_month = int(input("\nEnter your birth month: ")) 
                birth_date = int(input("\nEnter your birth date: "))
                if birth_year < 1000 or birth_year > 2025:
                    print("Year should be between 1000-2025")
                    continue
                    
                birth_day = date(birth_year, birth_month, birth_date)
                break 
                    
            except:
                print("Invalid date or number input")
                continue
      
    age = date.today().year-birth_year
    
    days_lived = (date.today()-birth_day).days
    
    next_birthday = date(date.today().year, birth_month, birth_date)
    
    if next_birthday < date.today():
        next_birthday = date(date.today().year+1, birth_month, birth_date)
        days_left = (next_birthday-date.today()).days
        
    days_left = (next_birthday-date.today()).days
    
    if (date.today().month, date.today().day) < (birth_month, birth_date):
       age -= 1
       
    day_name =  calendar.day_name[birth_day.weekday()]
                
    print(f"\nYou current age is {age} years")
    print(f"\nYou were born on {day_name}") 
    print(f"\nYou spent {days_lived} days on Earth till now")
    if days_left:
        print(f"\n{days_left} days left until your next birthday")