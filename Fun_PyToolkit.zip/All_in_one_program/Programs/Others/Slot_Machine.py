import random
import time

def menu():
    while True:
        print("\n🎰Slot Machine menu")
        print("1. Use")
        print("0. Return to Main Menu")
        try:
            user = int(input("\nEnter your choice: "))
            if user == 1:
                slot_machine() 
            elif user == 0:
                break
            else:
                print("Invalid choice")
        except ValueError:
            print("Please enter a valid number.")
            
def slot_machine():
    print("\nWelcome to slot machine here is the prize list below")
    print("1st prize: 🍋🍋🍋")
    print("2nd prize: 🍊🍊🍊")
    print("3rd prize: 🍉🍉🍉")
    fruits = ["🍎", "🍐", "🍌", "🍇", "🍓", "🍒", "🍉", "🍊", "🍋"]
    jackpot = ["🍋🍋🍋", "🍊🍊🍊", " 🍉🍉🍉"]
    weights = [30, 30, 30, 30, 30, 30, 10, 5, 2]
    while True:
        try:
            bid = int(input("\nEnter your bid amount: "))
            if bid <= 0:
                print("Bid cannot be 0 or negative try again")
                continue
            break
        except:
            print("Plz enter numbers only")
            continue
            
    input("\nPress enter so i can start the slot......")
    for i in range(3, 0, -1):
         print(f"\nStarting in {i}")
         time.sleep(1)
    result = random.choices(fruits, weights = weights, k=3)
    print("\nDone below is your slot result")
    print(f"\n{result}")
    if result == jackpot[0]:
        print("\nYou won first prize your money is 10x")
        print("\nFinal balance: ₹{bid}×10")
        bid = bid*10
    elif result == jackpot[1]:
        print("\nYou won second prize your money is 5x")
        print("\nFinal balance: ₹{bid}×10")
        bid = bid*5
    elif result == jackpot[2]:
        print("\nYou won third prize your money is 2x")
        print("\nFinal balance: ₹{bid}×10")
        bid = bid*2
    else:
        print("\nSorry you won nothing so your money is now ours")
        print("\nFinal balance: ₹0")
        bid = 0