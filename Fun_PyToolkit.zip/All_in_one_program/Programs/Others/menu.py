from Programs.Others import Password_Generator, Unit_converter, Birthday_info, Vending_Machine_Simulator, Slot_Machine

def menu():
    while True:
        print("\nOthers Menu")
        print("1. Password Generator")
        print("2. Unit Converter")
        print("3. Birthday Info")
        print("4. Vending Machine Simulator")
        print("5. Slot Machine")
        print("0. Back to Main Menu")

        try:
            choice = int(input("Choose an option: "))
            if choice == 1:
                Password_Generator.menu()
            elif choice == 2:
                Unit_converter.menu()
            elif choice == 3:
                Birthday_info.menu() 
            elif choice == 4:
                Vending_Machine_Simulator.menu()
            elif choice == 5:
                Slot_Machine.menu()
            elif choice == 0:
                break
            else:
                print("Invalid choice.")
        except ValueError:
            print("Please enter a number.")